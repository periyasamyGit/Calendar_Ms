package com.example.lcdetails.controller;

import com.example.lcdetails.dto.TeamMonthlyDetailsDto;
import com.example.lcdetails.service.LcDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/lc-details")
public class LcDetailsController {

    @Autowired
    private LcDetailsService service;

    @GetMapping
    public ResponseEntity<List<TeamMonthlyDetailsDto>> getDetails(
            @RequestParam("start") @DateTimeFormat(pattern = "dd MMMM yyyy") LocalDate start,
            @RequestParam("end") @DateTimeFormat(pattern = "dd MMMM yyyy") LocalDate end) {
        return ResponseEntity.ok(service.getDetails(start, end));
    }
}
