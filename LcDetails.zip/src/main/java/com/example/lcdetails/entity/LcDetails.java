package com.example.lcdetails.entity;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
public class LcDetails {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private Long teamId;
    private Long workupTypeId;
    private LocalDate proposedStartDate;
    private LocalDate proposedEndDate;

    // Getters and Setters
}
