package com.example.lcdetails.dto;

import java.time.LocalDate;

public class LcDetailDto {
    private Long workupTypeId;
    private LocalDate proposedStartDate;
    private LocalDate proposedEndDate;

    // Getters and Setters
}

public class TeamMonthlyDetailsDto {
    private Long teamId;
    private Map<String, List<LcDetailDto>> details;

    // Getters and Setters
}
