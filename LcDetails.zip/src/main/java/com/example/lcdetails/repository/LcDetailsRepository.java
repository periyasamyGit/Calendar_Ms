package com.example.lcdetails.repository;

import com.example.lcdetails.entity.LcDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import java.time.LocalDate;
import java.util.List;

public interface LcDetailsRepository extends JpaRepository<LcDetails, Long> {
    List<LcDetails> findByProposedStartDateLessThanEqualAndProposedEndDateGreaterThanEqual(LocalDate end, LocalDate start);
}
