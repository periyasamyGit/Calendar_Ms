package com.example.lcdetails.service;

import com.example.lcdetails.dto.LcDetailDto;
import com.example.lcdetails.dto.TeamMonthlyDetailsDto;
import com.example.lcdetails.entity.LcDetails;
import com.example.lcdetails.repository.LcDetailsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class LcDetailsService {

    @Autowired
    private LcDetailsRepository repository;

    public List<TeamMonthlyDetailsDto> getDetails(LocalDate startDate, LocalDate endDate) {
        List<LcDetails> lcDetails = repository.findByProposedStartDateLessThanEqualAndProposedEndDateGreaterThanEqual(endDate, startDate);
        Set<Long> teamIds = lcDetails.stream().map(LcDetails::getTeamId).collect(Collectors.toSet());

        List<YearMonth> months = new ArrayList<>();
        YearMonth current = YearMonth.from(startDate);
        YearMonth end = YearMonth.from(endDate);
        while (!current.isAfter(end)) {
            months.add(current);
            current = current.plusMonths(1);
        }

        List<TeamMonthlyDetailsDto> response = new ArrayList<>();

        for (Long teamId : teamIds) {
            Map<String, List<LcDetailDto>> monthlyDetails = new LinkedHashMap<>();

            for (YearMonth ym : months) {
                String monthName = ym.getMonth().getDisplayName(TextStyle.FULL, Locale.ENGLISH);

                List<LcDetailDto> records = lcDetails.stream()
                        .filter(d -> d.getTeamId().equals(teamId) && YearMonth.from(d.getProposedStartDate()).equals(ym))
                        .map(d -> {
                            LcDetailDto dto = new LcDetailDto();
                            dto.setWorkupTypeId(d.getWorkupTypeId());
                            dto.setProposedStartDate(d.getProposedStartDate());
                            dto.setProposedEndDate(d.getProposedEndDate().isAfter(endDate) ? endDate : d.getProposedEndDate());
                            return dto;
                        })
                        .collect(Collectors.toList());

                monthlyDetails.put(monthName, records);
            }

            TeamMonthlyDetailsDto dto = new TeamMonthlyDetailsDto();
            dto.setTeamId(teamId);
            dto.setDetails(monthlyDetails);
            response.add(dto);
        }

        return response;
    }
}
